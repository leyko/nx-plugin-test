import { createRequire } from 'module';const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// apps/service-test1/cdk/src/apis/test1/healthz/get/handler.ts
var handler = /* @__PURE__ */ __name(() => {
  return { statusCode: 204 };
}, "handler");
export {
  handler
};
// itzworking.io
