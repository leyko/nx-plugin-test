import { createRequire } from 'module';const require = createRequire(import.meta.url);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// apps/service-test1/cdk/src/events/ping-pong/handler.ts
var handler = /* @__PURE__ */ __name(() => {
  console.log("Ping event received. Pong!");
}, "handler");
export {
  handler
};
// itzworking.io
